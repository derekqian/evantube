This is the directory that holds the style and images for the jcarousel plugin for jquery javascript.

When designing a new PHPMotion V3 template, remember to style the carousel
and create the images that would match your new template.

