<?php
include_once "$base_path/addons/mw_eclipse/settings/eclipse_settings.php";