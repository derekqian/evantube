<?php

	$config['theme_thumbnail_width'] = 160;
	$config['theme_thumbnail_height'] = 120;
	$config['create_thumbnail_width'] = 160;
	$config['create_video_thumb_width'] = 160;
	$config['create_album_thumb_width'] = 160;
	$config['display_audio_album_thumb_width'] = 160;
	$config['index_display_video_thumb_width'] = 160;
	$config['general_large_thumb_width'] = 160;
	$config['general_medium_thumb_width'] = 80;
	$config['general_small_thumb_width'] = 30;
	$config['display_member_picture_width'] = 160;
	$config['show_member_videos'] = 4;



	$eclipse_skin = 'default';

	$eclipse_player = 'pmplayer';

	$dq_shortname = '';
	
	
// Social Button Settings	
	$soc_fburl = '';
	$soc_twurl = '';
	$soc_gpurl = '';
	
	

	